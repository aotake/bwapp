BODY, DIV, SPAN, PRE, CODE, TD, TH {
	line-height: 140%;
	font-size: 10pt;
	font-family: verdana,arial,sans-serif;
}

H1 {
	font-size: 12pt;
}

H4 {
	font-size: 10pt;
	font-weight: bold;
}

P.label {
	margin-bottom: 5px;
}
P.dt {
	margin-top: 0px;
	margin-bottom: 0px;
}
P.indent {
	margin-top: 0px;
	margin-left: 20px;
	margin-bottom: 0px;
}
P.method {
	background-color: #f0f0f0;
	padding: 2px;
	border: 1px #cccccc solid;
}

A {
	text-decoration: none;
}

A:link{
	color: #336699;
}

A:visited			{
	color: #003366;
}

A:active, A:hover	{
	color: #6699CC;
}

A:hover{
	text-decoration: underline;
}

SPAN.type			{
	color: #336699;
	font-size: xx-small;
	font-weight: normal;
	}

PRE	{
	background-color: #EEEEEE;
	padding: 10px;
	border-width: 1px;
	border-color: #336699;
	border-style: solid;
}

HR	{
	color: #336699;
	background-color: #336699;
	border-width: 0px;
	height: 1px;
	filter: Alpha (opacity=100,finishopacity=0,style=1);
}

DIV.sdesc			{
	font-weight: bold;
	background-color: #EEEEEE;
	padding: 10px;
	border-width: 1px;
	border-color: #336699;
	border-style: solid;
}

DIV.desc			{
	font-family: monospace;
	background-color: #EEEEEE;
	padding: 10px;
	border-width: 1px;
	border-color: #336699;
	border-style: solid;
}

SPAN.code			{
	font-family: monospace;
}

CODE.varsummarydefault{
	padding: 1px;
	border-width: 1px;
	border-style: dashed;
	border-color: #336699;
}

UL.tute	{
	margin:			0px;
	padding:		0px;
	padding-left:		5px;
	}

LI.tute	{
	line-height: 140%;
	font-size: 10pt;
	text-indent:		-15px;
	padding-bottom:		2px;
	padding-left:		14px;
}

.small{
	font-size: 9pt;
}


.tute-tag { color: #009999 }
.tute-attribute-name { color: #0000FF }
.tute-attribute-value { color: #0099FF }
.tute-entity { font-weight: bold; }
.tute-comment { font-style: italic }
.tute-inline-tag { color: #636311; font-weight: bold }
.src-code { font-family: 'Courier New', Courier, monospace; font-weight: normal; }
