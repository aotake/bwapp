BODY {
    background: #FFFFFF;
	font-family:		Arial;
	margin:			0px;
	padding:		0px;
}
A {
	color:                  #CC4400;
	font-weight:		bold;
}
A:Hover {
	color:			white;
	background-color:	#334B66;
	font-weight:		bold;
	text-decoration:	none;
}
	
#packageTitle {
	font-size:		160%;
	font-weight:		bold;
	text-align:		right;
	color:			#CC6633;
}
#packageTitle2 {
	font-size:		160%;
	font-weight:		bold;
	text-align:		right;
	color:			#334B66;
	background-color:       #6699CC;
}
#packageLinks {
	background-color:       #6699CC;
}
#header {
	background-color:       #6699CC;
	border-bottom:		solid #334B66 4px;
}
#nav {
	background-color:       #6699CC;
	padding:		4px;
	border-right:		solid #334B66 4px;
}
#index {
	padding:		18px;
}
hr {
	width:			80%;
	background-color:	#6699CC;
	color:			#6699CC;
	margin-top:		15px;
	margin-bottom:		15px;
	clear:			both;
}
.links {
	text-align:		left;
	width:			98%;
	margin:			auto;
}
UL {
	margin:			0px;
	padding:		0px;
	padding-left:		5px;
	list-style-type:	none;
}
li {
	text-indent:		-15px;
	padding-bottom:		2px;
	padding-left:		14px;
}
dd {
	margin-bottom:		.5em;
}
.small {
	font-size:		80%;
}
h3 {
}
.middleCol {
	margin-left:		-1px;
	border-right:		dotted gray 1px;
	border-left:		dotted gray 1px;
	padding:		5px;
}
.leftCol {
	border-right:		dotted gray 1px;
	padding:		5px;
}
.rightCol {
	margin-left:		-1px;
	border-left:		dotted gray 1px;
	padding:		5px;
}
#elementPath {
	font-size:		14px;
	font-weight:		bold;
	color:			#334B66;
}
.constructor {
	/*border:			dashed #334B66 1px;*/
	font-weight:		bold;
}
#credit {
	text-align:		center;
	color:			#334B66;
	font-weight:		bold;
}
div.contents {
	border:			solid #334B66 1px;
	padding:		3px;
	margin-bottom:		5px;
	clear:			all;
}
H1 {
	margin:			0px;
}
H2 {
	margin:			0px;
	margin-bottom:		2px;
}
H3 {
	margin:			0px;
}
H4 {
	margin:			0px;
}
#classTree {
	padding:		0px;
	margin:			0px;
}
div.indent {
	margin-left:		15px;
}
.warning {
	color:			red;
	background-color:	#334B66;
	font-weight:		bold;
}
code {
	font-family:		fixed;
	padding:		3px;
	color:			#334B66;
	background-color:	#dddddd;
}
.type {
	color:                  #334B66;
}
.value {
	color:                  #334B66;
	border:			dotted #334B66 1px;
}
.top {
	color:                  #334B66;
	border-bottom:		dotted #334B66 1px;
	padding-bottom:		4px;
}
.php-src, .php, .listing {
	font-family:		fixed;
	padding:		3px;
	color:			#334B66;
	background-color:	#dddddd;
	font-family: 'Courier New', Courier, monospace; font-weight: normal;
}
DIV#nav DL {
	margin:			0px;
	padding:		0px;
	list-style-type:	none;
}
div.classtree {
	font-size:		130%;
	font-weight:		bold;
	background-color:			#CC6633;
	border:		dotted #334B66 2px;
}
span.linenumber,p.linenumber {
	font-weight:		bold,italic;
}
span.smalllinenumber {
	font-weight:		bold,italic;
	font-size:		9pt;
}
ul {
	margin-left:		0px;
	padding-left:		8px;
}
/* Syntax highlighting */

.src-code { background-color: #f5f5f5; border: 1px solid #ccc9a4; padding: 0px; margin : 0px}
.src-line {  font-family: 'Courier New', Courier, monospace; font-weight: normal; }
/*.src-code pre {	}*/

.src-comm { color: green; }
.src-id {  }
.src-inc { color: #0000FF; }
.src-key { color: #0000FF; }
.src-num { color: #CC0000; }
.src-str { color: #66cccc; }
.src-sym { font-weight: bold; }
.src-var { }

.src-php { font-weight: bold; }

.src-doc { color: #009999 }
.src-doc-close-template { color: #0000FF }
.src-doc-coretag { color: #0099FF; font-weight: bold }
.src-doc-inlinetag { color: #0099FF }
.src-doc-internal { color: #6699cc }
.src-doc-tag { color: #0080CC }
.src-doc-template { color: #0000FF }
.src-doc-type { font-style: italic }
.src-doc-var { font-style: italic }

.tute-tag { color: #009999 }
.tute-attribute-name { color: #0000FF }
.tute-attribute-value { color: #0099FF }
.tute-entity { font-weight: bold; }
.tute-comment { font-style: italic }
.tute-inline-tag { color: #636311; font-weight: bold }

/* tutorial */

.authors {  }
.author { font-style: italic; font-weight: bold }
.author-blurb { margin: .5em 0em .5em 2em; font-size: 85%; font-weight: normal; font-style: normal }
.example { border: 1px dashed #999999; background-color: #EEEEEE; padding: .5em; }
.listing { border: 1px dashed #999999; background-color: #EEEEEE; padding: .5em; white-space: nowrap; }
.release-info { font-size: 85%; font-style: italic; margin: 1em 0em }
.ref-title-box {  }
.ref-title {  }
.ref-purpose { font-style: italic; color: #666666 }
.ref-synopsis {  }
.title { font-weight: bold; margin: 1em 0em 0em 0em; padding: .25em;
	border: 2px solid #CC6633; background-color: #6699CC }
.cmd-synopsis { margin: 1em 0em }
.cmd-title { font-weight: bold }
.toc { margin-left: 2em; padding-left: 0em }

