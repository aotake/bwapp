
body { background: #FFFFFF; }
body, table {
	font-family: Verdana, Arial, Helvetica, sans-serif; 
	text-align: left;
	font-size: 11px;
}

table.none td.btCell { background-color: #fff; vertical-align: top; }
table.none tr.highlight td.btCell { background-color: #f5f5f5; vertical-align: top; }
table.none th.btHead { background-color: #e5e5e5; vertical-align: top; }
table.btHeader, th.btHeader {
	background-color: #014f9d; 
	color: #fff;
	text-align: left;
	vertical-align: top;
}
table.btHeaderProminent, th.btHeaderProminent {
	background-color: #9d0119; 
	color: #fff;
	text-align: left;
	vertical-align: top;
}
div.showHideIndent { margin-left: 14px; }
td.left, th.left, th.syntaxLanguage { vertical-align: top; text-align: left; border-right: 1px solid #ceced8; border-bottom: solid 1px #ceced8; }
th.noborder { border: none; }
th.border { border: 1px solid #ceced8; }
td.border { border-bottom: 1px solid #ceced8; } 
th.syntaxLanguage { font-size: 11px; line-height: 13px; vertical-align: top; }
.faq, .property { color: #000090; }
.method { color: #009000; }
.event { color: #900000; }

table.default th.syntaxLanguage { font-size: 0.7em; vertical-align: baseline; }
.small { font-size: 85%; line-height: 120%; }

a {
	color: #000090;
	
}

div.maintutorial {
  border-width: thin;
  border-color: #0066ff;
}

.source, .src-code {
  border-width: thin;
  border-style: dashed;
  border-color: #8899dd;
  margin: 1em;
  padding: 0.5em;
  font-family: 'Courier New', Courier, monospace; font-weight: normal;
}
.src-line {  font-family: 'Courier New', Courier, monospace; font-weight: normal; }

.var-type {
  font-style : italic;
}

.var-title {
  margin-left : 20px;
}

.method-summary {
  margin-left : 20px;
}

/*------------------------------------------------------------------------------
    Show/Hide blocks
------------------------------------------------------------------------------*/

.shown { display: inline; }
.hidden { display: none; }
img.showHideImg, .showHideControl { cursor: hand; }
img.showHideImg { margin-right: 3px; }

.showHideActionText
{
  font-size: 0.7em;
}

.showHideActionTextContent
{
  font-weight: bold;
}

.showHideActionTextContentHover
{
  text-decoration: underline;
  font-weight: bold;
  background-color: #ceced8;
}
ol { 
	margin: 0.2em 0em 0.2em 24px; 
	padding: 0em; 
}
ul li { 
	margin: 0.2em 0em 0.2em 0em; padding: 0em; 
	list-style-position: outside; 
	list-style-type: square; 
}
span.li { 
	color: #000000; 
}
ul { 
	color: #014fbe; 
	margin: 3px 0em 3px 16px; 
}
p { 
	margin: 6px 0em 6px 0em; 
}
h1 { margin: 1em 0em 1.2em 0em; font-size: 160%; line-height: 130%;}
h2 { font-size: 125%; line-height: 120%;}
h1, h2, h3, h4 {
	padding: 0em;
	margin: 1.5em 0em .25em 0em;
	text-align: left;
	font-weight: normal;
}
h3 { margin-top: 0.5em; font-size: 110%; }
h4 { margin:  0.25em 0em .25em 0em;;  font-size: 100%; }

.Headline {
    color: #000000;
    font-family: Verdana,Arial,Helvetica,sans-serif;
    font-size: 9pt;
    font-weight: bold;
    font-style: normal;
/*    margin-left : -1.5em;*/
    text-align : left;
    margin-top : 1.0em;
    margin-bottom : 0.5em;
}

.HelpContent {
    margin-left : 1.5em;
}

table.HelpTable {
	border:			0px;
	padding:		0px;
	margin:			0px;
}

tr.HelpTable {
}

th.HelpTable {
	border:					1px dotted;
	background-color:		#F0F0F0;
	margin:					1px;
	padding:				5px;
}

td.HelpTable {
	border:			1px dotted;
	background-color:		#F9F9F9;
	margin:			1px;
	padding:				5px;
}

pre.depreciated {
    font-family: Verdana,Arial,Helvetica,sans-serif;
    font-size: 9pt;
	border:			1px dotted #909090;
	background-color:		#F0F0F0;
	margin-left:			10px;
	margin-right:			10px;
	margin-top:			10px;
	margin-bottom:			10px;
	padding:				5px;
}

/*------------------------------------------------------------------------------
    webfx-tree
------------------------------------------------------------------------------*/
.webfx-tree-container {
	margin: 0px;
	padding: 0px;
	font: icon;
	white-space: nowrap;
}

.webfx-tree-item {
	padding: 0px;
	margin: 0px;
	font: icon;
	color: black;
	white-space: nowrap;
}

.webfx-tree-item a, .webfx-tree-item a:active, .webfx-tree-item a:hover {
	margin-left: 3px;
	padding: 1px 2px 1px 2px;
}

.webfx-tree-item a {
	color: black;
	text-decoration: none;
}

.webfx-tree-item a:hover {
	color: blue;
	text-decoration: underline;
}

.webfx-tree-item a:active {
	background: highlight;
	color: highlighttext;
	text-decoration: none;
}

.webfx-tree-item img {
	vertical-align: middle;
	border: 0px;
}

.webfx-tree-icon {
	width: 16px;
	height: 16px;
}


.tute-tag { color: #009999 }
.tute-attribute-name { color: #0000FF }
.tute-attribute-value { color: #0099FF }
.tute-entity { font-weight: bold; }
.tute-comment { font-style: italic }
.tute-inline-tag { color: #636311; font-weight: bold }
