body 
{ 
	background-color: #CCCCFF; 
	margin: 0px; 
	padding: 0px;
}

/* Banner (top bar) classes */

.banner {  }

.banner-menu 
{ 
	clear: both;
	padding: .5em;
	border-top: 2px solid #6666AA;	
}

.banner-title 
{ 
	text-align: right; 
	font-size: 20pt; 
	font-weight: bold; 
	margin: .2em;
}

.package-selector 
{ 
	background-color: #AAAADD; 
	border: 1px solid black; 
	color: yellow;
}
