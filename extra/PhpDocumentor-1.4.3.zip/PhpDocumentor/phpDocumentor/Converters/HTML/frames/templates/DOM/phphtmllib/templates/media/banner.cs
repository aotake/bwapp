body 
{ 
	background-color: #DDDDDD;
	margin: 0px; 
	padding: 0px;
}

/* Banner (top bar) classes */

.banner {  }

.banner-menu 
{ 
	clear: both;
	padding: .5em;
	border-top: 2px solid #999999;	
}

.banner-title 
{ 
	text-align: right;
	font-size: 20pt;
	font-weight: bold;
	margin: .2em;
}

.package-selector 
{ 
	background-color: #CCCCCC;
	border: 1px solid black;
	color: blue;
}
