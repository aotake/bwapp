<?php
/** @package tests */
/**
* This is a Test
*/
function SendEMail($sendto = "\"Your Name\"
<your@email.here>")
{
}

/**
* a second test.
* Make sure that we are clearing out quote data after using it since how we
* set that values has changed
*/
function test_441433($test = "Some stuff in a quote")
{
}
?>
