<?php
/**
* @package tests
*/
/** 
this invalid docblock 
fails at cellog@php.net 
on the @sign 
**/
define('one','two');
?>