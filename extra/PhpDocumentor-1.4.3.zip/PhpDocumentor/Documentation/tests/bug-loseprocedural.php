<?php
/** @package tests */
/** test2 was lost, isn't any more */
function test
{
}
/** @package tests */
class testClass
{
	function testClass()
	{
	}
}

function test2()
{
}
?>

